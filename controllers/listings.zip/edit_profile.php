<?php

			$data = array(
				'response' => 'OK',
				'response_message' => 'Success',
				'responseData' => 
					 array('' => '')
					);

			echo json_encode($data);
?>